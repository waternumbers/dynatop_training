## h is the hru, p is a named vector of parameter values
fparChange <- function(h,p){
    ## change "m" transmissivty decay parameter depending upon atb class
    if( !is.na(h$class$atb_20) ){
        if( h$class$atb_20 < 20 ){
            h$sz$parameters["m"] <- p["m1"]
        }else{
            h$sz$parameters["m"] <- p["m2"]
        }
    }
    ## change unsaturated zone time constant regarless of type
    h$uz$parameters["t_d"] <- p["Td"]
    ## change surface velocity depending upon if it is a channel
    if( is.na(h$class$startNode) ){
        ## hillslope
        h$sf$parameters["c_sf"] <- p["csf"]
    }else{
        ## channel
        h$sf$parameters["c_sf"] <- p["vch"]
    }
    return(h)
}

## save the function
tmp <- deparse(fparChange); tmp[1] <- paste("fparChange <-",tmp[1])
writeLines(tmp,file.path(".","dyna","fparChange.R"))

## start by loading the model for reference
nsim <- 10000
sample <- cbind(
  sid = 1:nsim, ## the simulation identifier number
  Td = runif(nsim,0.1,120),
  m1 = runif(nsim,0.005,0.06),
  m2 = runif(nsim,0.005,0.06),
  csf = runif(nsim,0.05,0.5),
  vch = runif(nsim,0.2,1.4))
## save the random sample
saveRDS(sample,file.path(".","dyna","sample.rds"))

## normally this function would be entered into its own file.
## Here to show it we enter it then add it to a file
## inputs are i the index of a row of sample and the model - which is altered by the function
## It expects the sample, pattern, obs and q0 to be present in the workspace fMC is called from
## it does not need its own copy of these since they are not changed
fMC <- function(i,sample,mdl,obs,q0){
  x <- sample[i,] # the values to substitute in
  ## put sample values into model
  hru <- lapply( mdl$hru, fparChange,p=x) 
  ## put intial conditions into the model
  hru <- lapply(hru,function(h,q0){h$initialisation["r_uz_sz_0"] <- q0; h},q0=q0)
    ## simulate the model
  dt <- dynatop::dynatop$new(hru)$add_data(obs)$initialise()$sim(mdl$output_flux)
  ## get mass balance
  mb <- dt$get_mass_errors()
    if( any(abs(mb$err)>1e-3) ){ ## this is an error of greater then 1m^3
    stop("Mass Balance error in sid ",x["sid"])
  }
  ##ch_in <- dt$get_channel_inflow()
  gf <- dt$get_output()
  if(any(is.na(gf))){
    stop("non-finite flow returned")
  }
  ## ns = nash-sutcliffe
  ns <- 1 - sum((obs$Sheepmount_obs-gf$Sheepmount)^2,na.rm=TRUE) /
    sum((obs$Sheepmount_obs - mean(obs$Sheepmount_obs,na.rm=TRUE))^2,na.rm=TRUE)
  ## if good performance save some outputs to use
  if(ns>0.5){ 
    saveRDS(
      list(sid = x["sid"],
           gauge_flow=gf,
           mass_balance = mb),
      file.path(".","dyna",paste0("Simulation_",x["sid"],".rds"))
    )
  }
  return(ns)
}

## save the function
tmp <- deparse(fMC); tmp[1] <- paste("fMX <-",tmp[1])
writeLines(tmp,file.path(".","dyna","fMC.R"))

## ## source function for running
## source( file.path(".","dyna","fMC.R") ) ## source the function so it is available
## ## load model
## mdl <- readRDS(file.path(".","dyna","atb_20_model.rds"))
## ## load obs
## obs <- readRDS(file.path(".","processed","obs.rds"))
## ## load the parameter function
## source( file.path(".","dyna","fparChange.R"))
## ## load sample
## sample <- readRDS(file.path(".","dyna","sample.rds"))
## 
## q0 <- obs$Sheepmount_obs[1] / sum( sapply(mdl$hru,function(h){h$properties["area"]}) )
## 
## ## this wraps the fMC function to catch any errors and stop then killing the simulation
## fout <- function(i,sample,mdl,obs,q0){
##   tryCatch({fMC(i,sample,mdl,obs,q0)},
##            error=function(e){e$message}) ## if an error return the message
## }
## 
## ## use lapply to iterate over the parameter sets - this will run on a single R process
## #out <- lapply(seq_len(nrow(sample)), fout)
## 
## ## on linux/mac use mclapply to run across multiple cores on the same machine
## ## alter mc.cores to match the machine being used
## out <- mclapply(1:6,fMC,mdl=mdl,obs=obs,q0=q0,mc.cores=6,mc.preschedule = FALSE)
## ## on windows/linux/mac you could use parLapply but the set up is more complex
## ## The `future` package offer an alternative.
## 
## 
## ## save out after naming with the simulation number
## names(out) <- paste0("sid_",sample[,"sid"])
## saveRDS(out,"output.rds")

## 
## ## prices the command line arguments
## arg <- as.integer(commandArgs(trailingOnly = TRUE))
## if(!all(is.finite(arg))){ stop("Invalid command line arguments") }
## j <- arg[1]
## nj <- arg[2]
## 
## 
## library(dynatop)
## source( file.path(".","dyna","fMC.R") ) ## source the function so it is available
## ## load model
## mdl <- readRDS(file.path(".","processed","atb_band_model.rds"))
## ## load obs
## obs <- readRDS(file.path(".","processed","obs.rds"))
## ## source parameter change function
## pattern <- readRDS(file.path(".","dyna","fparChange.R"))
## ## load sample
## sample <- readRDS(file.path(".","dyna","sample.rds"))
## 
## q0 <- as.numeric(obs$Sheepmount_obs[1]) / sum( sapply(mdl$hru,function(h){h$properties["area"]}) )
## 
## ## this wraps the fMC function to catch any errors and stop then killing the simulation
## fout <- function(i){
##   tryCatch({fMC(i,mdl,q0)},
##            error=function(e){e$message}) ## if an error return the message
## }
## 
## ## use lapply to iterate over the parameter sets - this will run on a single R process
## idx <- seq(j,nrow(sample),by=nj) ## evaluate every nj rows
## out <- lapply(idx, fout)
## 
## ## save out after naming with the simulation number
## names(out) <- paste0("sid_",sample[idx,"sid"])
## saveRDS(out,paste0("output_",j,".rds"))
