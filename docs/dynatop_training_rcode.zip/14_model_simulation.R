mdl <- readRDS(file.path(".","processed","atb_band_model.rds"))
obs <- readRDS(file.path(".","processed","obs.rds"))

library(dynatop)
library(xts)
ctch_mdl <- dynatop$new(mdl)

ctch_mdl$add_data(obs)



## determining the initial recharge rate ad setting it in the model
mdl$hillslope$r_uz_sz0 <- as.numeric(obs$Sheepmount_obs[1]) / sum(mdl$hillslope$area)

ctch_mdl$initialise()$sim()

mb <- ctch_mdl$get_mass_errors()
head(mb)
plot( mb$err , main="Mass balance error",ylab="m^3")

## For simulated flows at the gauge sites
sim_gauge <- ctch_mdl$get_gauge_flow() ## extract the flow as an xts object
head(sim_gauge)

## Plot the simulated flows at the gauges
ctch_mdl$plot_gauge_flow()

plot( merge(obs$Sheepmount_obs,sim_gauge),main="Simulated and observed flows",
     legend.loc='topright')

## For inflows to the Channel HRU from the Hill-slope HRUs

channel_inflow <- ctch_mdl$get_channel_inflow() ## extract the flow as an xts object
## there is one column for each Channel HRU. The column names are the Channel HRU IDs (as strings)
## For example to see the start of the inflows to the 23,560 and 1602 channel HRUS
head(channel_inflow[,c("23","560","1602")])

## Plot the total inflow to all channel HRUs from the Hill-slopes
ctch_mdl$plot_channel_inflow(total=TRUE)
## setting total to FALSE plots all the channel HRUs inflows individually

## To get the inflows to the Channel HRU from the Hill-slope HRUs separated by surface and saturated zone contributions
sep_channel_inflow <- ctch_mdl$get_channel_inflow(separate=TRUE)
## for example the start of the inflow to the Channel HRUs with ID 23, 560 and 1602
head(sep_channel_inflow$saturated[,c("23","560","1602")]) ## inflow from the saturated zone
head(sep_channel_inflow$surface[,c("23","560","1602")]) ## inflow from the surface zone

## For an overall picture
ctch_mdl$plot_channel_inflow(total=TRUE,separate=TRUE)

## extract the current states as a data.frame
current_state <- ctch_mdl$get_states()
## columns correspond to the Hill-slope HRU ID, and the storage's in each of the four zones
head(current_state)

## a single state can be plotted at one time
ctch_mdl$plot_state("s_sz")

## Some simple manipulations of the Hill-slope HRU parameters

## set all Hill-slope HRU exponential decay (m) parameters to 0.03
mdl$hillslope$m <- 0.03

## set all Hill-slope HRU maximum depth parameters (D) to 10m
## where the topographic index is in the highest band
## Note that cls_* are the values taken by the * class in the model generation
mdl$hillslope$D[ mdl$hillslope$cls_atb_20==20 ] <- 10

## Let us repeat the same simulation
## keeping the states for every other time step
keep_times <- index(obs)[seq(2,nrow(obs),by=2)] ## an vector of time steps
ctch_mdl$initialise()$sim(keep_states=keep_times) ## passing the vector of time steps to the call

## extract the record of the states at each time step
state_rec <- ctch_mdl$get_states(record=TRUE) ## returns the whole record of states
head(names(state_rec)) ## the elements in state_rec are named after the time
head(state_rec[[format(keep_times[1])]]) ## those in keep_times are populated
head(state_rec[[format(index(obs)[1])]]) ## those not in keep_times are empty

## Create a time series plot of the saturated zone deficit
s_sz_rec <- lapply(state_rec,function(x){x$s_sz}) ## extra the saturated deficit from each time step
s_sz_rec <- do.call(rbind,s_sz_rec) ## convert them into a matrix
head(rownames(s_sz_rec)) ## the row names are the the times carried over from the names in state_rec
s_sz_rec <- as.xts(s_sz_rec) ## convert to and xts object using the rownames as times
names(s_sz_rec) <- paste(state_rec[[format(keep_times[1])]]$id) ## give column names as the HRU id
## for a the Hill-slope HRUs with IDs 2487, 3598 and 5201 the start of the time series are
head(s_sz_rec[,c("2487","3598","5201")])
## and a plot can be generated
plot(s_sz_rec[,c("2487","3598","5201")],main="Saturated zone deficit for select HRU",legend.loc="topright")

## Create a map of the root zone storage at 2020-02-03 02:00:00
s_rz_val <- state_rec[["2020-02-03 02:00:00"]][,c("id","s_rz")] ## extract the id and rz storage
## create a map of values by substituting s_rz for the id in the hru_id map
hru_id <- raster(ctch_mdl$get_model()$map$hillslope) ## open map from from file names stored in the model
s_rz_map<- raster::subs(hru_id, s_rz_val) ## substitute values into the map of HRU id numbers
## and plot
plot(s_rz_map,main="Root zone storage at 2020-02-03 02:00:00")

## initialise and simulate the model
ctch_mdl$initialise()$sim()
head(ctch_mdl$get_states()) ## state values after the initial run
## run again without initialising
## This will use the final states of the last simulation as the starting states
ctch_mdl$sim()
head(ctch_mdl$get_states()) ## different state values after the second run

new_mdl <- ctch_mdl$get_model() ## get the model structure from the dynatop object
head(new_mdl$hillslope) ## as the original model but will final states included
