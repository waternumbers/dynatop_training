## pacPath <- file.path(".","dynatop") ## path of the folder containing the package DESCRIPTION file
## ## the <package>::<function> format used below calls installed R packages without fully attaching then to the workspace
## Rcpp::compileAttributes(pacPath) ## compile the attributes of the C++/R linkage
## devtools::document(pacPath) ## compile the function documentation and NAMESPACE
## devtools::check(pacPath) ## check the package by building it and running tests
## ## The check function produces significant amounts of output. Significant notes, warning and errors are repeated at the end
## devtools::build(pacPath) ## If there are no warnings or errors in the check then call this to build the package
