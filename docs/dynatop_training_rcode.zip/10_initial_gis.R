## install.packages(c("rgeos","rgdal","raster","sp","ncdf4"))

library(raster)
library(sp)

dem <- raster(file.path(".","unprocessed","Eden_DEM.tif")) # load the dem as a raster layer
eden <- shapefile(file.path(".","unprocessed","Eden_Catchment")) # load the outline of the sub-catchments from the shapefile
channel <- shapefile(file.path(".","unprocessed","Eden_River_Network")) # load the river network from the shapefile
urban <- shapefile(file.path(".","unprocessed","Eden_Urban")) # load the urban area map from the shapefile

dem

 # read in the csv file to a date.frame
csvGauges <- read.csv(file.path(".","unprocessed","Eden_Gauge_Sites.csv"))
# convert the data frame to a SpatialPointsDataFrame - take projection from the DEM
gauges <- SpatialPointsDataFrame(coords=csvGauges[,c("x","y")],proj4string=crs(dem),data=csvGauges)

plot(dem) # underlying coloured image with scale
plot(urban,add=TRUE,col="grey") # grey polygons
plot(channel,add=TRUE,col="blue") # channels as blue lines
plot(eden,add=TRUE) # outlines of sub-catchments in black
plot(gauges,add=TRUE,col="red") # gauges as red +

## show data frame with id values
head(urban@data)
## rasterise using objectid as the raster value
urban_raster <- rasterize(urban, dem, field="objectid")
## plot the resulting raster
plot(urban_raster)

## show data frame with id values
head(eden@data)
## rasterise
eden_raster <- rasterize(eden, dem, field="id")
## plot the resulting raster
plot(eden_raster)

writeRaster(eden_raster,file.path(".","processed","eden.tif"),overwrite=TRUE)
writeRaster(urban_raster,file.path(".","processed","urban.tif"),overwrite=TRUE)

masked_dem <- mask(dem,eden_raster)
plot(masked_dem)
plot(eden,add=TRUE)

writeRaster(masked_dem,file.path(".","processed","dem.tif"),overwrite=TRUE)

## edenDEM <- rasterize(eden, dem, mask=TRUE)

head(channel@data)

gauges <- crop(gauges,eden)

gauges$chn_identifier <- character(nrow(gauges)) # initialise storage of the channel identifier
gauges$chn_distance <- numeric(nrow(gauges)) # initialise storage of the distance to the channel

## loop to compute nearest reach for each gauge
for(ii in 1:nrow(gauges)){
  tmp <- rgeos::gDistance(gauges[ii,], channel, byid=TRUE)
  jj <- which.min(tmp)
  gauges$chn_identifier[ii] <- channel$identifier[jj]
  gauges$chn_distance[ii] <- tmp[jj]
} 

selected <- channel[channel$identifier %in% gauges$chn_identifier,]
plot(eden) # outlines of subcatchments in black
plot(channel,add=TRUE,col="blue") # channel network in blue
plot(selected,add=TRUE,col="orange") # selected reachs in orange
plot(gauges,add=TRUE,col="red",pch=21) # gauges as red filled circles

shapefile(gauges,file.path(".","processed","gauges"))
