rm(list=ls())

## ----eval=FALSE---------------------------------------------------------------
devtools::load_all(file.path(".","dynatop")) ## attach the revised package
mdl <- readRDS(file.path(".","processed","atb_band_model.rds")) ## read in the model
obs <- readRDS(file.path(".","processed","obs.rds")) ## read in the observed data
mdl$options["transmissivity_profile"] <- "bounded_exponential_pet" ## change the option
dt <- dynatop$new(mdl) ## create the dynatop object
dt$add_data(obs) ## add the observed data
dt$initialise(obs$Sheepmount_obs[1]/sum(mdl$hillslope$area)) ##initialise the model
dt$sim() ## simulate
mb <- dt$get_mass_errors() ## get the mass balance data
mb$err <- rowSums(mb) ## compute the errors
plot(mb$err) ## plot the errors

