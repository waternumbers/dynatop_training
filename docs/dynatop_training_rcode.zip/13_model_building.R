## install.packages("dynatopGIS", repos = c("https://waternumbers.github.io/drat", "http://cran.rstudio.com"))

## install.packages("jsonlite")

library("dynatopGIS")
library("raster")

ctch <- dynatopGIS$new(file.path(".","dynaGIS","meta.json"))

ctch$add_dem(file.path(".","processed","dem.tif"))

channel <- shapefile(file.path(".","unprocessed","Eden_River_Network"))
head(channel@data)

ctch$add_channel(channel,property_names = c(length = "length", startNode = "startNode", endNode = "endNode"),default_width=5)

## channel$width <- 5 ## add column of widths to data frame, could be variable values
## ## add channels with a constant width of 5m
## ctch$add_channel(channel)
## ## this is short for
## ## ctch$add_channel(channel,property_names = c(length = "length", startNode = "startNode", endNode = "endNode",width="width"))
## ## since the default value of property_names are valid

ctch$compute_areas()

ctch$get_layer()

head(ctch$get_meta())

ctch$plot_layer("dem", add_channel=TRUE)

ctch$get_layer("dem")

ctch$sink_fill()

raster::plot( ctch$get_layer('filled_dem') - ctch$get_layer('dem'),
             main="Changes to height")

ctch$compute_properties()

##plot of topographic index (log(a/tan b))
ctch$plot_layer('atb')

## read in urban areas raster
tmp <- raster(file.path(".","processed","urban.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_urban.tif")) ## write out

## similar for the sub-catchments
tmp <- raster(file.path(".","processed","eden.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_eden.tif")) ## write out

ctch$add_layer("urban",file.path(".","processed","extended_urban.tif"))
ctch$add_layer("subcatch",file.path(".","processed","extended_eden.tif"))

tmp <- raster(file.path(".","processed","precip_id.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_precip_id.tif")) ## write out
ctch$add_layer("precip_id",file.path(".","processed","extended_precip_id.tif")) ## add to dynatopGIS catchment

ctch$get_layer()

ctch$compute_flow_lengths()

ctch$get_layer()
ctch$plot_layer("band")

## simple equally spaced cuts
ctch$classify("atb_20","atb",20)

## use the quantile function of the raster package to compute breaks
## note we need to include the min and max
brk <- quantile(ctch$get_layer("atb"),probs=seq(0,1,length=21))
ctch$classify("atb_20_equal","atb",brk)

ctch$get_class_method("atb_20_simple")
## returns the list of break points for the classes

ctch$combine_classes("atb_20_band",c("atb_20","band"))

ctch$combine_classes("atb_20_band_subcatch",c("atb_20","band","subcatch"))

tmp <- -ctch$get_layer("urban")
writeRaster(tmp,file.path(".","processed","neg_extended_eden.tif")) ## write out
ctch$add_layer("neg_urban",file.path(".","processed","neg_extended_eden.tif"))

ctch$combine_classes("atb_20_band_cut_neg_urban_burn","atb_20_band",burns="neg_urban")

ctch$get_class_method("atb_20_band")
## returns the list of break points for the cuts and layers burnt in

tmp <- data.frame(classification = c("atb_20_band","atb_20_band_subcatch","atb_20_band_cut_neg_urban_burn"),
                  Number_HRU = rep(NA,3))
for(ii in 1:3){
  tmp$Number_HRU[ii] <- length(unique(ctch$get_layer(tmp$classification[ii])))
}
knitr::kable(tmp)

ctch$create_model("atb_band_model", # name of new model
                  "atb_20_band", # classification to base model on
                  "band", # distance to use for determining flow routing
                  transmissivity = "bexp", #transmissivity profile to use in this case bounded exponential
                  rain_layer = "precip_id", # layer of input precipitation series ID
                  rain_label = "precip_" # characters added to values in rain_layer to get series name
                  )

list.files(file.path(".","dynaGIS"),pattern="atb_band_model*")

ctch$plot_layer("atb_band_model")

## load the model
mdl <- readRDS(file.path(".","dynaGIS","atb_band_model.rds")) ## read the model in
head(mdl$pet_input) ## shows that name of the PET input series is unknown
mdl$pet_input$name <- "PET" ## when actually it was called PET in the input data

## By default gauge table contains the list of the channel HRUs that have no downstream connect
mdl$gauge 
## To replace this read in the gauge locations generated mealier
gauges <- shapefile(file.path(".","processed","gauges"))
## create a new table to replace the one in the model
new_gauge <- data.frame(name = gauges@data$Site_Nm,
                        chn_dnt = gauges@data$chn_dnt)
new_gauge$id <- as.integer( sapply(new_gauge$chn_dnt,
                                   function(x){mdl$channel$id[mdl$channel$identifier==x]}))
new_gauge$chn_dnt <- NULL ## removes the column
## add the new table to the model
mdl$gauge <- new_gauge
## then save for later use
saveRDS(mdl,file.path(".","processed","atb_band_model.rds"))

