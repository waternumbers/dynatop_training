rm(list=ls()

install.packages("dynatopGIS", repos = c("https://waternumbers.github.io/drat", "http://cran.rstudio.com"))


## ----load_library-------------------------------------------------------------
library("dynatopGIS")


## ---- initialisation----------------------------------------------------------
ctch <- dynatopGIS$new(file.path(".","dynaGIS","meta.json"))


## ---- add_dem-----------------------------------------------------------------
ctch$add_dem(file.path(".","processed","dem.tif"))


## ----channel_data-------------------------------------------------------------
channel <- shapefile(file.path(".","unprocessed","Eden_River_Network"))
head(channel@data)


## ----add_channel_data---------------------------------------------------------
ctch$add_channel(channel,property_names = c(length = "length", startNode = "startNode", endNode = "endNode"),default_width=5)


## ----add_channel_data_not_run, eval=FALSE-------------------------------------
## channel$width <- 5 ## add column of widths to data frame, could be variable values
## ## add channels with a constant width of 5m
## ctch$add_channel(channel)
## ## this is short for
## ## ctch$add_channel(channel,property_names = c(length = "length", startNode = "startNode", endNode = "endNode",width="width"))
## ## since the default value of property_names are valid


## ----basic_properties---------------------------------------------------------
ctch$compute_areas()


## ---- list_layers-------------------------------------------------------------
ctch$get_layer()


## ---- get_meta----------------------------------------------------------------
head(ctch$get_meta())


## ---- plot--------------------------------------------------------------------
ctch$plot_layer("dem", add_channel=TRUE)


## ---- get_layer---------------------------------------------------------------
ctch$get_layer("dem")


## ---- sink_fill---------------------------------------------------------------
ctch$sink_fill()

raster::plot( ctch$get_layer('filled_dem') - ctch$get_layer('dem'),
             main="Changes to height")


## ---- calc_atb----------------------------------------------------------------
ctch$compute_properties()


## ---- plot_atb----------------------------------------------------------------
##plot of topographic index (log(a/tan b))
ctch$plot_layer('atb')


## ---- pad_class_layer---------------------------------------------------------
## read in urban areas raster
tmp <- raster(file.path(".","processed","urban.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_urban.tif")) ## write out

## similar for the sub-catchments
tmp <- raster(file.path(".","processed","eden.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_eden.tif")) ## write out


## ---- add_class_layer---------------------------------------------------------
ctch$add_layer("urban",file.path(".","processed","extended_urban.tif"))
ctch$add_layer("subcatch",file.path(".","processed","extended_eden.tif"))


## ---- add_rain_layer----------------------------------------------------------
tmp <- raster(file.path(".","processed","precip_id.tif"))
tmp <- extend(tmp,1,NA) ## extent with a row/column of NA on each edge
writeRaster(tmp,file.path(".","processed","extended_precip_id.tif")) ## write out
ctch$add_layer("precip_id",file.path(".","processed","extended_precip_id.tif")) ## add to dynatopGIS catchment


## ----get_layer_add_layer------------------------------------------------------
ctch$get_layer()


## ---- flow_length-------------------------------------------------------------
ctch$compute_flow_lengths()


## ---- flow_length_plot--------------------------------------------------------
ctch$get_layer()
ctch$plot_layer("band")


## ---- atb_band_cut------------------------------------------------------------
ctch$classify("atb_band_cut",cuts=list(atb=20,band=NA))


## ---- atb_subcatch_band_cut---------------------------------------------------
ctch$classify("atb_subcatch_band_cut",cuts=list(atb=20,subcatch=NA,band=NA))


## ----neg_urban----------------------------------------------------------------
tmp <- -ctch$get_layer("urban")
writeRaster(tmp,file.path(".","processed","neg_extended_eden.tif")) ## write out
ctch$add_layer("neg_urban",file.path(".","processed","neg_extended_eden.tif"))

## ---- atb_band_cut_urban_burn-------------------------------------------------
ctch$classify("atb_band_cut_neg_urban_burn",cuts=list(atb=20,band=NA),burns="neg_urban")


## ----see_class----------------------------------------------------------------
ctch$get_class_method("atb_band_cut_neg_urban_burn")
## returns the list of break points for the cuts and layers burnt in


## ----num_hru, echo=FALSE, results='asis'--------------------------------------
tmp <- data.frame(classification = c("atb_band_cut","atb_subcatch_band_cut","atb_band_cut_neg_urban_burn"),
                  Number_HRU = rep(NA,3))
for(ii in 1:3){
  tmp$Number_HRU[ii] <- length(unique(ctch$get_layer(tmp$classification[ii])))
}
knitr::kable(tmp)


## ---- model_atb_split---------------------------------------------------------
ctch$create_model("atb_band_model", # name of new model
                  "atb_band_cut", # classification to base model on
                  "band", # distance to use for determining flow routing
                  transmissivity = "bounded_exponential", #transmissivity profile to use
                  rain_layer = "precip_id", # layer of input precipitation series ID
                  rain_label = "precip_" # characters added to values in rain_layer to get series name
                  )


## ---- model files-------------------------------------------------------------
list.files(file.path(".","dynaGIS"),pattern="atb_band_model*")


## ----plot_model---------------------------------------------------------------
ctch$plot_layer("atb_band_model")


## ----alter_model_1------------------------------------------------------------
## load the model
mdl <- readRDS(file.path(".","dynaGIS","atb_band_model.rds")) ## read the model in
head(mdl$pet_input) ## shows that name of the PET input series is unknown
mdl$pet_input$name <- "PET" ## when actually it was called PET in the input data


## ----alter_model_2------------------------------------------------------------
## By default gauge table contains the list of the channel HRUs that have no downstream connect
mdl$gauge 
## To replace this read in the gauge locations generated mealier
gauges <- shapefile(file.path(".","processed","gauges"))
## create a new table to replace the one in the model
new_gauge <- data.frame(name = gauges@data$Site_Nm,
                        chn_dnt = gauges@data$chn_dnt)
new_gauge$id <- as.integer( sapply(new_gauge$chn_dnt,
                                   function(x){mdl$channel$id[mdl$channel$identifier==x]}))
new_gauge$chn_dnt <- NULL ## removes the column
## add the new table to the model
mdl$gauge <- new_gauge
## then save for later use
saveRDS(mdl,file.path(".","processed","atb_band_model.rds"))


