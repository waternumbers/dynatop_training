library("dynatopGIS")
library("terra")

## setwd("../eden_data")

ctch <- dynatopGIS$new(file.path(".","dynaGIS"))

ctch$add_catchment( file.path(".","processed","eden.tif") )

ctch$add_dem(file.path(".","processed","dem.tif"))

ctch$add_channel(file.path(".","processed","channel.shp"))

ctch$get_layer()

ctch$plot_layer("dem", add_channel=TRUE)

ctch$get_layer("dem")

ctch$sink_fill()

terra::plot( ctch$get_layer('filled_dem') - ctch$get_layer('dem'),
             main="Changes to height")

ctch$compute_band()
ctch$plot_layer("band")

ctch$compute_properties()

##plot of topographic index (log(a/tan b))
ctch$plot_layer('atb')

ctch$compute_flow_lengths(flow_routing="shortest")

ctch$get_layer()
ctch$plot_layer("shortest_flow_length")

ctch$add_layer(file.path(".","processed","urban.tif"),"urban")
ctch$add_layer(file.path(".","processed","precip_id.tif"),"precip_id")

ctch$get_layer()

## simple equally spaced cuts
ctch$classify("atb_20","atb",20)

## use the quantile function of the raster package to compute breaks
## note we need to include the min and max
brk <- global(ctch$get_layer("atb"), fun=quantile,probs = seq(0, 1, length = 21),na.rm=T)
ctch$classify("atb_20_equal","atb",brk)

head(ctch$get_method("atb_20"))
## returns the list of break points for the classes

ctch$combine_classes("atb_20_subcatch",c("atb_20","catchment"))

ctch$combine_classes("atb_20_subcatch_band",c("atb_20_subcatch","band"))

tmp <- -ctch$get_layer("urban")
writeRaster(tmp,file.path(".","processed","neg_extended_eden.tif"),overwrite=TRUE) ## write out
ctch$add_layer(file.path(".","processed","neg_extended_eden.tif"),"neg_urban")

ctch$combine_classes("atb_20_subcatch_band_burn_neg_urban","atb_20_subcatch_band",burns="neg_urban")

tmp <- ctch$get_method("atb_20_subcatch")
tmp$type
head(tmp$groups)
## returns the list of break points for the cuts and layers burnt in

ctch$combine_classes("atb_20_band",c("atb_20","band")) ## so we can complete the table
ctch$combine_classes("atb_20_subcatch_burn_neg_urban","atb_20_subcatch",burn="neg_urban") ## so we can complete the table

fnc <- function(nm){ length(unique(ctch$get_layer(nm))[[1]] ) }
    
tmp <- data.frame(classification = c("atb_20","atb_20_subcatch","atb_20_subcatch_band_burn_neg_urban"),
                  Classes = c( fnc("atb_20"), fnc("atb_20_subcatch"), fnc("atb_20_subcatch_burn_neg_urban")),
                  HRU = c( fnc("atb_20_band"), fnc("atb_20_subcatch_band"), fnc("atb_20_subcatch_band_burn_neg_urban"))
                  )
knitr::kable(tmp)

ctch$create_model(file.path("./dyna","atb_20_model"), # name of new model
                  "atb_20_band", # classification to base model on
                  sf_opt="cnst",
                  sz_opt="exp",
                  rain_layer = "precip_id", # layer of input precipitation series ID
                  rain_label = "precip_" # characters added to values in rain_layer to get series name
                  )

list.files(file.path("./dyna"),pattern="atb_20_model")

## load the model
mdl <- readRDS( file.path(".","dyna","atb_20_model.rds")) ## read the model in
names(mdl)

mdl$map

names(mdl$hru[[8]])

mdl$output_flux

## To replace this read in the gauge locations generated mealier
gauges <- vect(file.path(".","processed","gauges.shp"))
## create a vector of the uid's of the HRUs
hid <- sapply(mdl$hru,function(h){h$id})
## create a vector of the channel names with as storaged in the class variabel
cname <- sapply(mdl$hru,function(h){h$class$name})
idx <- match(gauges$chn_identi,cname) ## index of HRU's corresponding to gauges
## create as a data.frame
gauge_output <- data.frame(name = gauges$Site.Name,
                           id = as.integer(hid[idx]),
                           flux = "q_sf")
saveRDS(gauge_output,file.path(".","dyna","gauge_output_defn.rds")) ## save the output for later use
gauge_output

