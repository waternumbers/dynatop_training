rm(list=ls())
install.packages("xts")


## ----dynatop_install, eval=FALSE----------------------------------------------
install.packages("dynatop", repos = c("https://waternumbers.github.io/drat", "http://cran.rstudio.com"))


## ----attach_obs---------------------------------------------------------------
library(raster)
library(xts)
library(dynatop)


## ----show_eden_flow-----------------------------------------------------------
cat(readLines(file.path(".","unprocessed","Eden_Flow.csv"),5),sep="\n")


## ----read_eden_flow-----------------------------------------------------------
flow <- as.xts(read.zoo(file.path(".","unprocessed","Eden_Flow.csv"),header=TRUE,sep=",",drop=FALSE))
head(flow)


## ----open_precip--------------------------------------------------------------
## read in as a multilayered object
precip_brk <- brick(file.path(".","unprocessed","Eden_Precip.nc"))
## show summary
precip_brk
## show start of the z values which are the time stamps as character strings
head(getZ(precip_brk))


## ----rainfall_id--------------------------------------------------------------
rid <- raster(precip_brk[[1]])
rid <- setValues(rid,1:ncell(rid))
rid


## ----rainfall_out-------------------------------------------------------------
precip <- getValues(precip_brk) # matrix where each row is one cell
## add row names based on unique values in rid to give time series names
rownames(precip) <-  paste0("precip_",getValues(rid))
## get times as characters and convert to R internal time representation (POSIXct)
precip_datetime <- as.POSIXct(getZ(precip_brk),tz="GMT")
## create the xts object
precip <- xts(t(precip),order.by=precip_datetime)


## ----resample_time------------------------------------------------------------
## call the resample_precip function
resampled_precip <- resample_xts(precip,900)
## look at what it does (assigned rainfall equally between new steps in same time period)
head(precip[,"precip_48"]) # original data
head(resampled_precip) # resampled data - see how they sum to the original values


## ----resample_space-----------------------------------------------------------
## load the dem
dem <- raster(file.path(".","processed","dem.tif"))
## call the resample_precip function
reproj_rid <- projectRaster(rid,dem,method="ngb")
## mask so only values for finite DEM cells
reproj_rid <- mask(reproj_rid,dem)
## A plot for visualisation
plot(reproj_rid)
## save
writeRaster(reproj_rid,file.path(".","processed","precip_id.tif"))


## ----pet----------------------------------------------------------------------
## use a maximum of 3 mm/day - output in meters
pet <- evap_est(index(flow), eMin = 0, eMax = 0.003)
names(pet) <- "PET" # ensure series has a name


## ----merge--------------------------------------------------------------------
obs <- merge(flow,resampled_precip,pet,all=FALSE) ## merge by time stamp
saveRDS(obs,file.path(".","processed","obs.rds"))

